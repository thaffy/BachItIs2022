#Write a program that displays the following information: Your Name, Your Adress, with city and state, your telephone number and your college major

navn='Markus Hamre'
adresse='Osloveien 3, Hønefoss, Ringerike'
tlfnr='977 49 465'
studie='Bachelor i informasjonsteknologi'

print('Jeg heter',navn,)
print('Min adresse er',adresse)
print('Mitt telefonnummer er',tlfnr)
print('Jeg studerer',studie)

