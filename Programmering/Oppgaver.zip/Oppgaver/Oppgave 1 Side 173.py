# Number Analyzer

integer=int(input('Enter an integer: '))

if integer<0:
    integer_value=('Negative')
else:
    if integer>0:
        integer_value=('Positive')
    else:
        integer_value=('Zero')
odd_or_even=integer_value%2

if odd_or_even 
    integer_type=('Odd')
else:
    integer_type=('Even')






print(integer,integer_value)
