#A company has determined that its annual profit is typically 23 percent of total sales.
#Write a program that asks the user to enter the projected amount of total sales
#Which then displays the profit that will be made from that amount
# - Hint: Use the value 0.23 to represent 2.3 percent

total_sales=int(input('What is your projected amount of total sales? '))
projected_profit=total_sales*0.23

print('Your projected profit will be',projected_profit,)


