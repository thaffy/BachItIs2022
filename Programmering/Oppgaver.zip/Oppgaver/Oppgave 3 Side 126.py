#One pound is equivalent to 0.454 kilograms.
#Write a program that asks the user to enter the mass of an object in pounds and displays the mass of the object in kilograms

pounds=int(input('Please enter the mass of an object in pounds. '))

kilogram_conversion=pounds*0.454

print('The mass of your object is equivalent to',kilogram_conversion,'in kilograms! ')

