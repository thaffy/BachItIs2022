package Oblig2_Registrering;

public class Programstart {
    public static void main(String[] args) {
        Grensesnitt grensesnitt = new Grensesnitt();
        grensesnitt.hovedmeny();
    }
}
