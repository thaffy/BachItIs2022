
public class DiktProgram {

	public static void main(String[] args) {
		Grensesnitt grensesnitt = new Grensesnitt();
		// Kaller metoden meny():
		grensesnitt.hovedmeny();
		

	}

}
